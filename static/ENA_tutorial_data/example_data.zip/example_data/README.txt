README
The folder example_data contains a series of example data and 
files to be used in a demonstration on how to submit 3 SARS-CoV-2 
samples to an example project, along with raw read data and sequences 
associated with each sample. 

The files are organised as follows:

01-route/
01-route/runs/
01-route/runs/pairedfastq.tsv
01-route/runs/paired_fastq_manifest_sample1.txt
01-route/runs/paired_fastq_manifest_sample2.txt
01-route/runs/paired_fastq_manifest_sample3.txt
01-route/sequences/
01-route/sequences/hCoV-19_isolate_1_manifest.txt
01-route/sequences/hCoV-19_isolate_2_manifest.txt
01-route/sequences/hCoV-19_isolate_3_manifest.txt

02-route/
02-route/runs/
02-route/runs/experiments.xml
02-route/runs/runs.xml
02-route/runs/submission.xml
02-route/samples/
02-route/samples/samples.xml
02-route/samples/submission.xml
02-route/samples/submission_modify.xml
02-route/study/
02-route/study/project.xml
02-route/study/submission.xml

data/
data/raw/
data/raw/SARS-CoV-2-Sample1_1.fastq.gz
data/raw/SARS-CoV-2-Sample1_2.fastq.gz
data/raw/SARS-CoV-2-Sample2_1.fastq.gz
data/raw/SARS-CoV-2-Sample2_2.fastq.gz
data/raw/SARS-CoV-2-Sample3_1.fastq.gz
data/raw/SARS-CoV-2-Sample3_2.fastq.gz
data/sequences/
data/sequences/hCoV-19_isolate_1.fasta.gz
data/sequences/hCoV-19_isolate_1_chrm_list.txt.gz
data/sequences/hCoV-19_isolate_2.fasta.gz
data/sequences/hCoV-19_isolate_2_chrm_list.txt.gz
data/sequences/hCoV-19_isolate_3.fasta.gz
data/sequences/hCoV-19_isolate_3_chrm_list.txt.gz
data/samples/
data/samples/sample_spreadsheet.tsv
data/samples/sample_spreadsheet.xlsx



